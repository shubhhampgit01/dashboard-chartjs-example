
import './App.css'
import Sidebar from './components/sidebar'
import Dashboard from './pages/dashboard'

function App() {

  return (
    <div className="app">
      <Sidebar />
      <div className="mainPage">
        <Dashboard/>
      </div>
    </div>
  )
}

export default App
