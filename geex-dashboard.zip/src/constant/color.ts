export const Colors = {
    primary_text_color: '#403c4f',
    nobel: '#b6b6b6',
    french_lilac: '#ECDFF5',
    lavender: '#b262de',
    scarpa_flow: '#5a5667',
    chart_green: '#00A389',
    chart_red: '#FF5B5B',
    chart_purple: '#AB54DB',
    sea_pink: '#EF9A91',
    sidecar: '#F1E6B9',
    chart_yellow: '#FFB543'
}